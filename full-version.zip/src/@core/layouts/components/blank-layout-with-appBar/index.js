// ** Next Import
import Link from 'next/link'

// ** MUI Imports
import AppBar from '@mui/material/AppBar'
import Toolbar from '@mui/material/Toolbar'
import Typography from '@mui/material/Typography'
import { styled, useTheme } from '@mui/material/styles'

// ** Configs
import themeConfig from 'src/configs/themeConfig'

const StyledLink = styled('a')(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  textDecoration: 'none',
  marginRight: theme.spacing(8)
}))

const BlankLayoutAppBar = () => {
  // ** Hooks
  const theme = useTheme()

  return (
    <AppBar elevation={3} color='default' position='sticky'>
      <Toolbar
        sx={{
          justifyContent: 'space-between',
          p: theme => `${theme.spacing(0, 6)} !important`,
          minHeight: `${theme.mixins.toolbar.minHeight}px !important`
        }}
      >
        <Link href='/' passHref>
          <StyledLink>
          <svg width={40} version="1.0" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 125.000000 125.000000"
 preserveAspectRatio="xMidYMid meet">

<g transform="translate(0.000000,125.000000) scale(0.100000,-0.100000)"
fill="#000000" stroke="none">
<path d="M756 827 c-18 -13 -35 -75 -36 -129 0 -26 0 -26 30 -12 29 15 30 18
30 85 0 38 -1 69 -3 69 -2 0 -11 -6 -21 -13z"/>
<path d="M678 782 c-26 -15 -27 -20 -27 -90 1 -73 1 -73 22 -59 17 11 24 29
30 73 4 33 6 67 5 76 -3 16 -5 16 -30 0z"/>
<path d="M598 732 c-21 -23 -31 -102 -13 -102 7 0 20 -3 29 -6 14 -5 16 3 16
54 0 66 -9 81 -32 54z"/>
<path d="M805 680 c-3 -4 -14 -6 -24 -3 -11 3 -39 -10 -71 -32 -47 -33 -58
-37 -96 -31 -32 4 -47 1 -61 -12 -10 -9 -14 -14 -9 -9 6 4 16 7 24 7 10 0 6
-9 -12 -26 -14 -15 -26 -34 -26 -44 0 -9 -6 -30 -14 -46 -22 -46 -28 -74 -17
-74 6 0 11 9 11 21 0 21 67 92 80 84 4 -2 26 -8 49 -14 l43 -9 -4 38 c-2 21 0
36 3 34 7 -4 14 -38 25 -126 9 -70 26 -59 20 12 -4 45 -2 59 7 53 7 -4 20 -6
30 -5 21 4 22 -17 2 -44 -17 -22 -19 -34 -5 -34 16 0 41 71 43 126 2 45 4 51
19 43 33 -18 40 -11 32 36 -6 41 -4 45 14 45 41 0 29 15 -14 17 -24 1 -46 -2
-49 -7z"/>
<path d="M500 530 c-6 -11 -21 -25 -32 -29 -18 -6 -19 -9 -5 -14 11 -4 23 4
38 24 12 17 19 33 16 35 -3 3 -11 -4 -17 -16z"/>
<path d="M555 470 c-8 -16 -15 -35 -15 -42 1 -7 7 2 15 20 9 21 21 32 34 32
11 0 23 5 26 10 3 6 -5 10 -19 10 -18 0 -30 -9 -41 -30z"/>
<path d="M244 366 c-11 -28 1 -51 26 -53 22 -1 22 -1 3 4 -25 5 -33 47 -10 56
9 4 9 6 -1 6 -7 1 -15 -5 -18 -13z"/>
<path d="M770 370 c0 -5 7 -7 15 -4 8 4 15 8 15 10 0 2 -7 4 -15 4 -8 0 -15
-4 -15 -10z"/>
<path d="M303 345 c-3 -9 -3 -18 -1 -21 3 -3 8 4 11 16 6 23 -1 27 -10 5z"/>
<path d="M402 338 c2 -12 10 -23 18 -25 12 -4 13 -3 1 5 -8 6 -11 17 -8 26 4
9 2 16 -4 16 -6 0 -9 -10 -7 -22z"/>
<path d="M487 342 c-24 -26 -21 -32 11 -31 16 1 20 3 10 6 -10 2 -18 7 -18 10
0 3 8 12 18 19 9 7 12 14 6 14 -6 0 -18 -8 -27 -18z"/>
<path d="M532 340 c0 -14 2 -19 5 -12 2 6 2 18 0 25 -3 6 -5 1 -5 -13z"/>
<path d="M613 345 c-3 -9 -3 -18 -1 -21 3 -3 8 4 11 16 6 23 -1 27 -10 5z"/>
<path d="M657 339 c4 -13 8 -18 11 -10 2 7 -1 18 -6 23 -8 8 -9 4 -5 -13z"/>
<path d="M683 341 c1 -14 9 -26 17 -28 10 -3 11 -2 4 4 -7 4 -14 17 -17 28 -5
16 -5 15 -4 -4z"/>
<path d="M981 341 c-1 -18 -5 -22 -21 -18 -11 3 -20 1 -20 -4 0 -5 9 -9 20 -9
22 0 35 21 27 42 -3 7 -6 2 -6 -11z"/>
<path d="M1000 330 c0 -16 2 -30 4 -30 2 0 6 14 8 30 3 17 1 30 -4 30 -4 0 -8
-13 -8 -30z"/>
<path d="M1046 342 c4 -14 0 -22 -13 -25 -17 -4 -17 -5 0 -6 21 -1 34 26 19
41 -8 8 -9 5 -6 -10z"/>
<path d="M820 336 c0 -14 -6 -17 -25 -14 -13 3 -22 1 -19 -3 9 -15 44 -10 51
6 3 9 3 19 -1 22 -3 4 -6 -2 -6 -11z"/>
<path d="M347 319 c7 -7 15 -10 18 -7 3 3 -2 9 -12 12 -14 6 -15 5 -6 -5z"/>
<path d="M557 318 c2 -5 10 -8 18 -8 8 0 16 3 18 8 3 4 -5 7 -18 7 -13 0 -21
-3 -18 -7z"/>
<path d="M877 318 c2 -5 10 -8 18 -8 8 0 16 3 18 8 3 4 -5 7 -18 7 -13 0 -21
-3 -18 -7z"/>
</g>
</svg>
            <Typography variant='h6' sx={{ ml: 2, fontWeight: 700, lineHeight: 1.2 }}>
              {themeConfig.templateName}
            </Typography>
          </StyledLink>
        </Link>
      </Toolbar>
    </AppBar>
  )
}

export default BlankLayoutAppBar
