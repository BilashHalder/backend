// ** Next Import
import Link from 'next/link'

// ** MUI Imports
import IconButton from '@mui/material/IconButton'
import Box from '@mui/material/Box'
import { styled, useTheme } from '@mui/material/styles'
import Typography from '@mui/material/Typography'

// ** Icons
import Close from 'mdi-material-ui/Close'

// ** Configs
import themeConfig from 'src/configs/themeConfig'

// ** Styled Components
const MenuHeaderWrapper = styled(Box)(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  paddingRight: theme.spacing(4),
  justifyContent: 'space-between',
  transition: 'padding .25s ease-in-out',
  minHeight: theme.mixins.toolbar.minHeight
}))

const HeaderTitle = styled(Typography)({
  fontWeight: 700,
  lineHeight: 1.2,
  transition: 'opacity .25s ease-in-out, margin .25s ease-in-out'
})

const StyledLink = styled('a')({
  display: 'flex',
  alignItems: 'center',
  textDecoration: 'none'
})

const VerticalNavHeader = props => {
  // ** Props
  const {
    hidden,
    navHover,
    settings,
    saveSettings,
    collapsedNavWidth,
    toggleNavVisibility,
    navigationBorderWidth,
    menuLockedIcon: userMenuLockedIcon,
    menuUnlockedIcon: userMenuUnlockedIcon,
    verticalNavMenuBranding: userVerticalNavMenuBranding
  } = props

  // ** Hooks & Vars
  const theme = useTheme()
  const { skin, direction, navCollapsed } = settings
  const menuCollapsedStyles = navCollapsed && !navHover ? { opacity: 0 } : { opacity: 1 }

  const svgFillSecondary = () => {
    if (skin === 'semi-dark' && theme.palette.mode === 'light') {
      return `rgba(${theme.palette.customColors.dark}, 0.68)`
    } else if (skin === 'semi-dark' && theme.palette.mode === 'dark') {
      return `rgba(${theme.palette.customColors.light}, 0.68)`
    } else {
      return theme.palette.text.secondary
    }
  }

  const svgFillDisabled = () => {
    if (skin === 'semi-dark' && theme.palette.mode === 'light') {
      return `rgba(${theme.palette.customColors.dark}, 0.38)`
    } else if (skin === 'semi-dark' && theme.palette.mode === 'dark') {
      return `rgba(${theme.palette.customColors.light}, 0.38)`
    } else {
      return theme.palette.text.disabled
    }
  }

  const menuHeaderPaddingLeft = () => {
    if (navCollapsed && !navHover) {
      if (userVerticalNavMenuBranding) {
        return 0
      } else {
        return (collapsedNavWidth - navigationBorderWidth - 40) / 8
      }
    } else {
      return 5.5
    }
  }

  const svgRotationDeg = () => {
    if (navCollapsed) {
      if (direction === 'rtl') {
        if (navHover) {
          return 0
        } else {
          return 180
        }
      } else {
        if (navHover) {
          return 180
        } else {
          return 0
        }
      }
    } else {
      if (direction === 'rtl') {
        return 180
      } else {
        return 0
      }
    }
  }

  return (
    <MenuHeaderWrapper className='nav-header' sx={{ pl: menuHeaderPaddingLeft() }}>
      {userVerticalNavMenuBranding ? (
        userVerticalNavMenuBranding(props)
      ) : (
        <Link href='/' passHref>
          <StyledLink>
          <svg width={40} version="1.0" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 125.000000 125.000000"
 preserveAspectRatio="xMidYMid meet">

<g transform="translate(0.000000,125.000000) scale(0.100000,-0.100000)"
fill="#000000" stroke="none">
<path d="M756 827 c-18 -13 -35 -75 -36 -129 0 -26 0 -26 30 -12 29 15 30 18
30 85 0 38 -1 69 -3 69 -2 0 -11 -6 -21 -13z"/>
<path d="M678 782 c-26 -15 -27 -20 -27 -90 1 -73 1 -73 22 -59 17 11 24 29
30 73 4 33 6 67 5 76 -3 16 -5 16 -30 0z"/>
<path d="M598 732 c-21 -23 -31 -102 -13 -102 7 0 20 -3 29 -6 14 -5 16 3 16
54 0 66 -9 81 -32 54z"/>
<path d="M805 680 c-3 -4 -14 -6 -24 -3 -11 3 -39 -10 -71 -32 -47 -33 -58
-37 -96 -31 -32 4 -47 1 -61 -12 -10 -9 -14 -14 -9 -9 6 4 16 7 24 7 10 0 6
-9 -12 -26 -14 -15 -26 -34 -26 -44 0 -9 -6 -30 -14 -46 -22 -46 -28 -74 -17
-74 6 0 11 9 11 21 0 21 67 92 80 84 4 -2 26 -8 49 -14 l43 -9 -4 38 c-2 21 0
36 3 34 7 -4 14 -38 25 -126 9 -70 26 -59 20 12 -4 45 -2 59 7 53 7 -4 20 -6
30 -5 21 4 22 -17 2 -44 -17 -22 -19 -34 -5 -34 16 0 41 71 43 126 2 45 4 51
19 43 33 -18 40 -11 32 36 -6 41 -4 45 14 45 41 0 29 15 -14 17 -24 1 -46 -2
-49 -7z"/>
<path d="M500 530 c-6 -11 -21 -25 -32 -29 -18 -6 -19 -9 -5 -14 11 -4 23 4
38 24 12 17 19 33 16 35 -3 3 -11 -4 -17 -16z"/>
<path d="M555 470 c-8 -16 -15 -35 -15 -42 1 -7 7 2 15 20 9 21 21 32 34 32
11 0 23 5 26 10 3 6 -5 10 -19 10 -18 0 -30 -9 -41 -30z"/>
<path d="M244 366 c-11 -28 1 -51 26 -53 22 -1 22 -1 3 4 -25 5 -33 47 -10 56
9 4 9 6 -1 6 -7 1 -15 -5 -18 -13z"/>
<path d="M770 370 c0 -5 7 -7 15 -4 8 4 15 8 15 10 0 2 -7 4 -15 4 -8 0 -15
-4 -15 -10z"/>
<path d="M303 345 c-3 -9 -3 -18 -1 -21 3 -3 8 4 11 16 6 23 -1 27 -10 5z"/>
<path d="M402 338 c2 -12 10 -23 18 -25 12 -4 13 -3 1 5 -8 6 -11 17 -8 26 4
9 2 16 -4 16 -6 0 -9 -10 -7 -22z"/>
<path d="M487 342 c-24 -26 -21 -32 11 -31 16 1 20 3 10 6 -10 2 -18 7 -18 10
0 3 8 12 18 19 9 7 12 14 6 14 -6 0 -18 -8 -27 -18z"/>
<path d="M532 340 c0 -14 2 -19 5 -12 2 6 2 18 0 25 -3 6 -5 1 -5 -13z"/>
<path d="M613 345 c-3 -9 -3 -18 -1 -21 3 -3 8 4 11 16 6 23 -1 27 -10 5z"/>
<path d="M657 339 c4 -13 8 -18 11 -10 2 7 -1 18 -6 23 -8 8 -9 4 -5 -13z"/>
<path d="M683 341 c1 -14 9 -26 17 -28 10 -3 11 -2 4 4 -7 4 -14 17 -17 28 -5
16 -5 15 -4 -4z"/>
<path d="M981 341 c-1 -18 -5 -22 -21 -18 -11 3 -20 1 -20 -4 0 -5 9 -9 20 -9
22 0 35 21 27 42 -3 7 -6 2 -6 -11z"/>
<path d="M1000 330 c0 -16 2 -30 4 -30 2 0 6 14 8 30 3 17 1 30 -4 30 -4 0 -8
-13 -8 -30z"/>
<path d="M1046 342 c4 -14 0 -22 -13 -25 -17 -4 -17 -5 0 -6 21 -1 34 26 19
41 -8 8 -9 5 -6 -10z"/>
<path d="M820 336 c0 -14 -6 -17 -25 -14 -13 3 -22 1 -19 -3 9 -15 44 -10 51
6 3 9 3 19 -1 22 -3 4 -6 -2 -6 -11z"/>
<path d="M347 319 c7 -7 15 -10 18 -7 3 3 -2 9 -12 12 -14 6 -15 5 -6 -5z"/>
<path d="M557 318 c2 -5 10 -8 18 -8 8 0 16 3 18 8 3 4 -5 7 -18 7 -13 0 -21
-3 -18 -7z"/>
<path d="M877 318 c2 -5 10 -8 18 -8 8 0 16 3 18 8 3 4 -5 7 -18 7 -13 0 -21
-3 -18 -7z"/>
</g>
</svg>
            <HeaderTitle variant='h6' sx={{ ...menuCollapsedStyles, ...(navCollapsed && !navHover ? {} : { ml: 2 }) }}>
              {themeConfig.templateName}
            </HeaderTitle>
          </StyledLink>
        </Link>
      )}

      {hidden ? (
        <IconButton
          disableRipple
          disableFocusRipple
          onClick={toggleNavVisibility}
          sx={{ p: 0, backgroundColor: 'transparent !important' }}
        >
          <Close fontSize='small' />
        </IconButton>
      ) : (
        <IconButton
          disableRipple
          disableFocusRipple
          onClick={() => saveSettings({ ...settings, navCollapsed: !navCollapsed })}
          sx={{ p: 0, color: 'text.primary', backgroundColor: 'transparent !important' }}
        >
          {userMenuLockedIcon && userMenuUnlockedIcon ? (
            navCollapsed ? (
              userMenuUnlockedIcon
            ) : (
              userMenuLockedIcon
            )
          ) : (
            <Box
              width={22}
              fill='none'
              height={22}
              component='svg'
              viewBox='0 0 22 22'
              xmlns='http://www.w3.org/2000/svg'
              sx={{
                transform: `rotate(${svgRotationDeg()}deg)`,
                transition: 'transform .25s ease-in-out .35s'
              }}
            >
              <path
                fill={svgFillSecondary()}
                d='M11.4854 4.88844C11.0082 4.41121 10.2344 4.41121 9.75716 4.88844L4.51029 10.1353C4.03299 10.6126 4.03299 11.3865 4.51029 11.8638L9.75716 17.1107C10.2344 17.5879 11.0082 17.5879 11.4854 17.1107C11.9626 16.6334 11.9626 15.8597 11.4854 15.3824L7.96674 11.8638C7.48943 11.3865 7.48943 10.6126 7.96674 10.1353L11.4854 6.61667C11.9626 6.13943 11.9626 5.36568 11.4854 4.88844Z'
              />
              <path
                fill={svgFillDisabled()}
                d='M15.8683 4.88844L10.6214 10.1353C10.1441 10.6126 10.1441 11.3865 10.6214 11.8638L15.8683 17.1107C16.3455 17.5879 17.1193 17.5879 17.5965 17.1107C18.0737 16.6334 18.0737 15.8597 17.5965 15.3824L14.0779 11.8638C13.6005 11.3865 13.6005 10.6126 14.0779 10.1353L17.5965 6.61667C18.0737 6.13943 18.0737 5.36568 17.5965 4.88844C17.1193 4.41121 16.3455 4.41121 15.8683 4.88844Z'
              />
            </Box>
          )}
        </IconButton>
      )}
    </MenuHeaderWrapper>
  )
}

export default VerticalNavHeader
