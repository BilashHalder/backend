// ** React Imports
import { useEffect, useState } from 'react'

// ** Import All Icons
import * as Icons from 'mdi-material-ui'

// ** Axios Import
import axios from 'axios'

const ServerSideNavItems = () => {
  // ** State
  const [menuItems, setMenuItems] = useState([])
  useEffect(() => {
    axios.get('/api/horizontal-nav/data').then(response => {
      const menuArray = response.data
      const finalMenuArray = items => {
        return items.map(item => {
          if (item.icon) {
            // @ts-ignore
            item.icon = Icons[item.icon]
            if (item.children) {
              finalMenuArray(item.children)
            }

            return item
          }

          return item
        })
      }
      setMenuItems(finalMenuArray(menuArray))
    })
  }, [])

  return menuItems
}

export default ServerSideNavItems
